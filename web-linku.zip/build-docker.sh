#!/bin/bash
docker rm -f c1_web_linku
docker build --tag=c1_web_linku .
docker run -p 1337:1337 --rm --name=c1_web_linku c1_web_linku